﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=CarDealerXML;Integrated Security=True;Encrypt=False";
    }
}
