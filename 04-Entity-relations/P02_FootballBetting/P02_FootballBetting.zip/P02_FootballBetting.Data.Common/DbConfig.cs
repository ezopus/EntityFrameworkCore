﻿namespace P02_FootballBetting.Data.Common;

public class DbConfig
{
    public const string ConnectionString =
        "Server=.;Database=FootballBookmakerSystem;TrustServerCertificate=True;Integrated Security=True;";
}

